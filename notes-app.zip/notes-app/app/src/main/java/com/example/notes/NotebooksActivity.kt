package com.example.notes

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class NotebooksActivity : Activity() {
    private lateinit var list: ListView
    private var items = mutableListOf<Notebook>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val title = TextView(this).apply {
            text = "دفاتري"; textSize = 26f; setTextColor(Color.BLACK)
            setPadding(40, 60, 40, 30); gravity = Gravity.START
        }
        val add = Button(this).apply {
            text = "+ دفتر جديد"
            setOnClickListener { newNotebook() }
        }
        list = ListView(this)
        root.addView(title)
        root.addView(add)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ ->
            startActivity(Intent(this, EditorActivity::class.java).putExtra("id", items[pos].id))
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this)
                .setTitle("حذف \"${items[pos].name}\"؟")
                .setPositiveButton("حذف") { _, _ ->
                    Store.deleteNotebook(this, items[pos])
                    items.removeAt(pos); Store.saveNotebooks(this, items); refresh()
                }
                .setNegativeButton("إلغاء", null).show()
            true
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        items = Store.notebooks(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            items.map { "${it.name}  (${it.pages} صفحة)" })
    }

    private fun newNotebook() {
        val et = EditText(this).apply { hint = "اسم الدفتر" }
        AlertDialog.Builder(this).setTitle("دفتر جديد").setView(et)
            .setPositiveButton("إنشاء") { _, _ ->
                val name = et.text.toString().ifBlank { "دفتر بدون اسم" }
                items.add(Notebook(System.currentTimeMillis().toString(), name, 1))
                Store.saveNotebooks(this, items); refresh()
            }
            .setNegativeButton("إلغاء", null).show()
    }
}
