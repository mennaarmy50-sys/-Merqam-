package com.example.notes

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class DrawingView(ctx: Context) : View(ctx) {
    var strokes = mutableListOf<Stroke>()
    var color = Color.BLACK
    var penWidth = 5f
    var eraser = false
    var stylusOnly = true
    var onChanged: (() -> Unit)? = null

    private var cur: Stroke? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val linePaint = Paint().apply { color = 0xFFDDE6F0.toInt(); strokeWidth = 2f }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.WHITE)
        var y = 90f
        while (y < height) { c.drawLine(0f, y, width.toFloat(), y, linePaint); y += 90f }
        for (s in strokes) drawStroke(c, s)
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        paint.color = s.color
        paint.strokeWidth = s.width
        val n = s.pts.size / 2
        if (n == 0) return
        if (n == 1) { c.drawPoint(s.pts[0], s.pts[1], paint); return }
        val p = Path()
        p.moveTo(s.pts[0], s.pts[1])
        for (i in 1 until n) {
            val px = s.pts[2 * (i - 1)]; val py = s.pts[2 * (i - 1) + 1]
            val x = s.pts[2 * i]; val y = s.pts[2 * i + 1]
            p.quadTo(px, py, (px + x) / 2, (py + y) / 2)
        }
        p.lineTo(s.pts[2 * (n - 1)], s.pts[2 * (n - 1) + 1])
        c.drawPath(p, paint)
    }

    private fun erase(x: Float, y: Float) {
        val r = 30f
        strokes.removeAll { s ->
            var hit = false
            var i = 0
            while (i < s.pts.size) {
                val dx = s.pts[i] - x; val dy = s.pts[i + 1] - y
                if (dx * dx + dy * dy < r * r) { hit = true; break }
                i += 2
            }
            hit
        }
    }

    fun undo() {
        if (strokes.isNotEmpty()) { strokes.removeAt(strokes.size - 1); invalidate(); onChanged?.invoke() }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        // رفض راحة اليد: تجاهل الإصبع لما "القلم فقط" يكون مفعّل
        if (stylusOnly && e.getToolType(0) == MotionEvent.TOOL_TYPE_FINGER) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (eraser) erase(e.x, e.y)
                else {
                    val s = Stroke(color, penWidth)
                    s.pts.add(e.x); s.pts.add(e.y)
                    strokes.add(s); cur = s
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (eraser) erase(e.x, e.y)
                else cur?.let { s ->
                    for (h in 0 until e.historySize) {
                        s.pts.add(e.getHistoricalX(h)); s.pts.add(e.getHistoricalY(h))
                    }
                    s.pts.add(e.x); s.pts.add(e.y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                cur = null
                onChanged?.invoke()
            }
        }
        invalidate()
        return true
    }
}
