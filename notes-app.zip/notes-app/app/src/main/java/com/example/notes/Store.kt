package com.example.notes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Stroke(val color: Int, val width: Float, val pts: MutableList<Float> = mutableListOf())
class Notebook(val id: String, var name: String, var pages: Int)

object Store {
    private fun file(c: Context, n: String) = File(c.filesDir, n)

    fun notebooks(c: Context): MutableList<Notebook> {
        val f = file(c, "notebooks.json")
        val out = mutableListOf<Notebook>()
        if (!f.exists()) return out
        val a = JSONArray(f.readText())
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Notebook(o.getString("id"), o.getString("name"), o.getInt("pages")))
        }
        return out
    }

    fun saveNotebooks(c: Context, list: List<Notebook>) {
        val a = JSONArray()
        for (n in list) a.put(JSONObject().put("id", n.id).put("name", n.name).put("pages", n.pages))
        file(c, "notebooks.json").writeText(a.toString())
    }

    fun loadPage(c: Context, id: String, i: Int): MutableList<Stroke> {
        val f = file(c, "nb_${id}_p$i.json")
        val out = mutableListOf<Stroke>()
        if (!f.exists()) return out
        val a = JSONArray(f.readText())
        for (k in 0 until a.length()) {
            val o = a.getJSONObject(k)
            val s = Stroke(o.getInt("c"), o.getDouble("w").toFloat())
            val p = o.getJSONArray("p")
            for (j in 0 until p.length()) s.pts.add(p.getDouble(j).toFloat())
            out.add(s)
        }
        return out
    }

    fun savePage(c: Context, id: String, i: Int, strokes: List<Stroke>) {
        val a = JSONArray()
        for (s in strokes) {
            val p = JSONArray()
            for (v in s.pts) p.put(v.toDouble())
            a.put(JSONObject().put("c", s.color).put("w", s.width.toDouble()).put("p", p))
        }
        file(c, "nb_${id}_p$i.json").writeText(a.toString())
    }

    fun deleteNotebook(c: Context, nb: Notebook) {
        for (i in 0 until nb.pages) file(c, "nb_${nb.id}_p$i.json").delete()
    }
}
