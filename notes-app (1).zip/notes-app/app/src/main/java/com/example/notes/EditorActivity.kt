package com.example.notes

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.*

class EditorActivity : Activity() {
    private lateinit var nb: Notebook
    private lateinit var all: MutableList<Notebook>
    private lateinit var view: DrawingView
    private lateinit var pageLabel: TextView
    private var page = 0
    private val colors = intArrayOf(Color.BLACK, 0xFF1565C0.toInt(), 0xFFC62828.toInt(), 0xFF2E7D32.toInt())
    private val widths = floatArrayOf(4f, 8f, 14f)
    private var ci = 0
    private var wi = 0
    private var lang = "ar"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        all = Store.notebooks(this)
        val id = intent.getStringExtra("id")
        val found = all.firstOrNull { it.id == id }
        if (found == null) { finish(); return }
        nb = found

        view = DrawingView(this)
        view.onChanged = { save() }
        pageLabel = TextView(this).apply { setPadding(24, 0, 24, 0); setTextColor(Color.BLACK) }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: (Button) -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f(this) }; bar.addView(this)
        }
        btn("رجوع") { save(); finish() }
        btn("قلم") { view.eraser = false }
        btn("ممحاة") { view.eraser = true }
        btn("اللون") { view.eraser = false; ci = (ci + 1) % colors.size; view.color = colors[ci] }
        btn("السمك") { wi = (wi + 1) % widths.size; view.penWidth = widths[wi] }
        btn("تراجع") { view.undo() }
        btn("القلم فقط: نعم") { bt ->
            view.stylusOnly = !view.stylusOnly
            bt.text = if (view.stylusOnly) "القلم فقط: نعم" else "القلم فقط: لا"
        }
        btn("اللغة: عربي") { bt ->
            lang = if (lang == "ar") "en" else "ar"
            bt.text = if (lang == "ar") "اللغة: عربي" else "اللغة: English"
        }
        btn("تحويل لنص") { convert() }
        btn("◀") { go(page - 1) }
        bar.addView(pageLabel)
        btn("▶") { go(page + 1) }
        btn("+ صفحة") { addPage() }

        val scroll = HorizontalScrollView(this).apply { addView(bar) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(scroll)
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        view.strokes = Store.loadPage(this, nb.id, page)
        pageLabel.text = "${page + 1} / ${nb.pages}"
        view.invalidate()
    }

    private fun save() {
        Store.savePage(this, nb.id, page, view.strokes)
        Store.saveNotebooks(this, all)
    }

    private fun go(p: Int) {
        if (p < 0 || p >= nb.pages) return
        save(); page = p; load()
    }

    private fun addPage() {
        save(); nb.pages += 1; page = nb.pages - 1
        Store.saveNotebooks(this, all); load()
    }

    private fun convert() {
        val dlg = AlertDialog.Builder(this).setMessage("لحظة...").setCancelable(true).show()
        Recognizer.recognize(view.strokes, lang,
            onStatus = { dlg.setMessage(it) },
            onResult = { txt ->
                dlg.dismiss()
                AlertDialog.Builder(this).setTitle("النص").setMessage(txt)
                    .setPositiveButton("نسخ") { _, _ ->
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("note", txt))
                        Toast.makeText(this, "اتنسخ", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("إغلاق", null).show()
            },
            onError = { dlg.dismiss(); Toast.makeText(this, it, Toast.LENGTH_LONG).show() })
    }

    override fun onPause() { super.onPause(); save() }
}
