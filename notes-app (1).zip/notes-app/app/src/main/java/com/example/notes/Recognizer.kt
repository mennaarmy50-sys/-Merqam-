package com.example.notes

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.Ink

object Recognizer {
    fun recognize(
        strokes: List<Stroke>,
        langTag: String,
        onStatus: (String) -> Unit,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (strokes.isEmpty()) { onError("الصفحة فاضية، اكتبي حاجة الأول"); return }
        val id = DigitalInkRecognitionModelIdentifier.fromLanguageTag(langTag)
        if (id == null) { onError("اللغة مش مدعومة"); return }
        val model = DigitalInkRecognitionModel.builder(id).build()
        val manager = RemoteModelManager.getInstance()

        val ink = Ink.builder()
        var t = 0L
        for (s in strokes) {
            val sb = Ink.Stroke.builder()
            var i = 0
            while (i + 1 < s.pts.size) {
                sb.addPoint(Ink.Point.create(s.pts[i], s.pts[i + 1], t))
                t += 10; i += 2
            }
            t += 200
            ink.addStroke(sb.build())
        }
        val built = ink.build()

        fun run() {
            onStatus("بحوّل الخط لنص...")
            val rec = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
            rec.recognize(built)
                .addOnSuccessListener { r ->
                    val txt = r.candidates.firstOrNull()?.text ?: ""
                    if (txt.isBlank()) onError("معرفتش أقرأ الخط") else onResult(txt)
                }
                .addOnFailureListener { onError("حصل خطأ في التحويل") }
        }

        manager.isModelDownloaded(model).addOnSuccessListener { downloaded ->
            if (downloaded) run()
            else {
                onStatus("بنزّل نموذج اللغة (مرة واحدة بس، محتاج إنترنت)...")
                manager.download(model, DownloadConditions.Builder().build())
                    .addOnSuccessListener { run() }
                    .addOnFailureListener { onError("فشل تنزيل النموذج، اتأكدي من الإنترنت") }
            }
        }.addOnFailureListener { onError("حصل خطأ") }
    }
}
